#include "MovieTree.h"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

MovieTree::MovieTree()
{
    //ctor
}

MovieTree::~MovieTree()
{
    //dtor
}

void MovieTree::menu()
{
    cout<<"======Main Menu======"<<endl;
    cout<<"1. Find a movie"<<endl;
    cout<<"2. Rent a movie"<<endl;
    cout<<"3. Print the inventory"<<endl;
    cout<<"4. Quit"<<endl;
}

void MovieTree::addMovieNode(int ranking,string title,int releaseYear,int quantity)
{
    MovieNode *temp=root;
    MovieNode *node=new MovieNode;
    node->parent=NULL;
    node->leftChild=NULL;
    node->rightChild=NULL;
    MovieNode *p=NULL;
    node= new MovieNode(ranking,title,releaseYear,quantity);
    while (temp!=NULL)
    {
        p=temp;
        if (node->title<temp->title)
            temp=temp->leftChild;
        else
            temp=temp->rightChild;
    }
    if (p==NULL)
        root=node;
    else if (node->title<p->title)
    {
        p->leftChild=node;
        node->parent=p;
    }
    else
    {
        p->rightChild=node;
        node->parent=p;
    }
}

void MovieTree::findMovie(string title)
{
    MovieNode *foundMovie=root;
    int flag=0;
    while (foundMovie!=NULL)
    {
        if (foundMovie->title>title)
            foundMovie=foundMovie->leftChild;
        else if (foundMovie->title<title)
            foundMovie=foundMovie->rightChild;
        else
        {
            cout<<"Movie Info:"<<endl;
            cout<<"==========="<<endl;
            cout<<"Ranking:"<<foundMovie->ranking<<endl;
            cout<<"Title:"<<foundMovie->title<<endl;
            cout<<"Year:"<<foundMovie->year<<endl;
            cout<<"Quantity:"<<foundMovie->quantity<<endl;
            flag=1;
            break;
        }
    }
    if (flag==0)
        cout<<"Movie not found."<<endl;
}

void MovieTree::rentMovie(string title)
{
    MovieNode *foundMovie=root;
    int flag=0;
    while (foundMovie!=NULL)
    {
        if (foundMovie->title>title)
            foundMovie=foundMovie->leftChild;
        else if (foundMovie->title<title)
            foundMovie=foundMovie->rightChild;
        else
        {
            if (foundMovie->quantity==0)
                cout<<"Movie out of stock."<<endl;
            else
            {
                cout<<"Movie has been rented."<<endl;
                cout<<"Movie Info:"<<endl;
                cout<<"==========="<<endl;
                cout<<"Ranking:"<<foundMovie->ranking<<endl;
                cout<<"Title:"<<foundMovie->title<<endl;
                cout<<"Year:"<<foundMovie->year<<endl;
                foundMovie->quantity=foundMovie->quantity-1;
                cout<<"Quantity:"<<foundMovie->quantity<<endl;

            }

            flag=1;
            break;
        }
    }
    if (flag==0)
        cout<<"Movie not found."<<endl;
}

void MovieTree::printMovieInventory(MovieNode *node)
{
    if (node->leftChild!=NULL)
        printMovieInventory(node->leftChild);
    cout<<"Movie: "<<node->title<<" "<<node->quantity<<endl;
    if (node->rightChild!=NULL)
        printMovieInventory(node->rightChild);
}

void MovieTree::printMovieInventory()
{
    MovieNode *node=root;
    printMovieInventory(node);
}
